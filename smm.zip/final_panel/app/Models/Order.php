<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Order extends Model {
    protected $fillable = ['user_id','service_id','link','quantity','total','status','remains','api_order_id','start_count'];
    public function user()    { return $this->belongsTo(User::class); }
    public function service() { return $this->belongsTo(Service::class); }
}
