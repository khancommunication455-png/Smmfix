<?php
// ── User ───────────────────────────────────────────────────────────────────
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;
    protected $fillable = [
        'name','email','password','funds','referral_code',
        'referred_by','telegram_user_id','status','is_admin',
    ];
    protected $hidden   = ['password','remember_token'];
    protected $casts    = ['email_verified_at'=>'datetime','funds'=>'float','is_admin'=>'boolean'];

    protected static function booted(): void
    {
        static::creating(function ($u) {
            $u->referral_code = strtoupper(substr(md5($u->email.time()),0,8));
        });
        static::created(function ($u) {
            // Credit referrer 5% of first deposit (handled in FundsController)
        });
    }

    public function orders()       { return $this->hasMany(Order::class); }
    public function transactions() { return $this->hasMany(Transaction::class); }
    public function tickets()      { return $this->hasMany(Ticket::class); }
    public function referrals()    { return $this->hasMany(User::class,'referred_by'); }
    public function referrer()     { return $this->belongsTo(User::class,'referred_by'); }
}
