<?php
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\{User, Transaction};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Auth, Hash, DB};

class RegisterController extends Controller
{
    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|email|unique:users,email',
            'password' => 'required|min:8|confirmed',
        ]);

        $referrer = null;
        if ($request->referral_code) {
            $referrer = User::where('referral_code', $request->referral_code)->first();
        }

        $user = User::create([
            'name'        => $request->name,
            'email'       => $request->email,
            'password'    => Hash::make($request->password),
            'funds'       => 0,
            'referred_by' => $referrer?->id,
            'status'      => 'active',
        ]);

        Auth::login($user);
        return redirect()->route('dashboard')->with('success', 'Welcome! Your account has been created.');
    }
}
