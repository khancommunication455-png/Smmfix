<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\{Order, User, Service, Category, ApiProvider, Transaction, Ticket};
use App\Services\ProviderApiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{DB, Log};

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            abort_unless(auth()->user()?->is_admin, 403, 'Admin access required.');
            return $next($request);
        });
    }

    // ── Dashboard ──────────────────────────────────────────────────────────
    public function dashboard()
    {
        $total_revenue  = Transaction::where('type','deposit')->where('status','completed')->sum('amount');
        $total_orders   = Order::count();
        $active_users   = User::where('status','active')->count();
        $pending_orders = Order::whereIn('status',['pending','in progress'])->count();
        $recent_orders  = Order::with(['user','service'])->latest()->take(10)->get();
        $recent_users   = User::latest()->take(6)->get();
        $providers      = ApiProvider::all();

        return view('admin.dashboard', compact(
            'total_revenue','total_orders','active_users','pending_orders',
            'recent_orders','recent_users','providers'
        ));
    }

    // ── Sync all services from all providers ───────────────────────────────
    public function syncAll()
    {
        $synced = 0;
        foreach (ApiProvider::where('status','active')->get() as $provider) {
            try {
                $api      = new ProviderApiService($provider);
                $services = $api->getServices();
                if (!is_array($services)) continue;

                foreach ($services as $s) {
                    $cat = Category::firstOrCreate(
                        ['name' => $s['category'] ?? 'General'],
                        ['status' => 'active', 'icon' => 'list_alt', 'color' => '#adc6ff']
                    );
                    Service::updateOrCreate(
                        ['api_provider_id' => $provider->id, 'api_service_id' => $s['service']],
                        [
                            'name'        => $s['name'],
                            'category_id' => $cat->id,
                            'rate'        => round($s['rate'] * (1 + ($provider->percentage_increase / 100)), 6),
                            'min'         => $s['min'],
                            'max'         => $s['max'],
                            'status'      => 'active',
                            'type'        => 'api',
                        ]
                    );
                    $synced++;
                }
            } catch (\Throwable $e) {
                Log::error("Sync failed for provider {$provider->id}: " . $e->getMessage());
            }
        }
        return response()->json(['message' => "Synced {$synced} services successfully."]);
    }

    // ── Sync single provider ───────────────────────────────────────────────
    public function syncProvider(ApiProvider $provider)
    {
        try {
            $api      = new ProviderApiService($provider);
            $services = $api->getServices();
            $synced   = 0;

            foreach (($services ?? []) as $s) {
                $cat = Category::firstOrCreate(
                    ['name' => $s['category'] ?? 'General'],
                    ['status' => 'active', 'icon' => 'list_alt', 'color' => '#adc6ff']
                );
                Service::updateOrCreate(
                    ['api_provider_id' => $provider->id, 'api_service_id' => $s['service']],
                    [
                        'name'        => $s['name'],
                        'category_id' => $cat->id,
                        'rate'        => round($s['rate'] * (1 + ($provider->percentage_increase / 100)), 6),
                        'min'         => $s['min'],
                        'max'         => $s['max'],
                        'status'      => 'active',
                        'type'        => 'api',
                    ]
                );
                $synced++;
            }
            return back()->with('success', "Synced {$synced} services from {$provider->name}.");
        } catch (\Throwable $e) {
            return back()->with('error', "Sync failed: " . $e->getMessage());
        }
    }

    // ── Providers CRUD ─────────────────────────────────────────────────────
    public function providersIndex()
    {
        $providers = ApiProvider::withCount('services')->get();
        return view('admin.providers.index', compact('providers'));
    }

    public function providersCreate()
    {
        return view('admin.providers.create');
    }

    public function providersStore(Request $request)
    {
        $request->validate([
            'name'                => 'required|string|max:100',
            'url'                 => 'required|url',
            'api_key'             => 'required|string|max:255',
            'percentage_increase' => 'required|numeric|min:0|max:10000',
        ]);
        ApiProvider::create($request->only('name','url','api_key','percentage_increase') + ['status' => 'active']);
        return redirect()->route('admin.providers.index')->with('success', 'Provider added. Click Sync to import services.');
    }

    public function providersEdit(ApiProvider $provider)
    {
        return view('admin.providers.edit', compact('provider'));
    }

    public function providersUpdate(Request $request, ApiProvider $provider)
    {
        $request->validate([
            'name'                => 'required|string|max:100',
            'url'                 => 'required|url',
            'api_key'             => 'required|string|max:255',
            'percentage_increase' => 'required|numeric|min:0|max:10000',
            'status'              => 'required|in:active,inactive',
        ]);
        $provider->update($request->only('name','url','api_key','percentage_increase','status'));
        return back()->with('success', 'Provider updated.');
    }

    // ── Orders management ──────────────────────────────────────────────────
    public function ordersIndex(Request $request)
    {
        $orders = Order::with(['user','service'])
            ->when($request->status, fn($q,$s) => $q->where('status',$s))
            ->when($request->search, fn($q,$s) => $q->where('id',$s)->orWhereHas('user',fn($u) => $u->where('name','like',"%$s%")))
            ->latest()->paginate(30);
        return view('admin.orders.index', compact('orders'));
    }

    public function ordersUpdateStatus(Request $request, Order $order)
    {
        $request->validate(['status' => 'required|in:pending,in progress,completed,cancelled,refunded,partial']);
        $order->update(['status' => $request->status]);
        return back()->with('success', "Order #{$order->id} status updated.");
    }

    // ── Users management ───────────────────────────────────────────────────
    public function usersIndex(Request $request)
    {
        $users = User::withCount('orders')
            ->when($request->search, fn($q,$s) => $q->where('name','like',"%$s%")->orWhere('email','like',"%$s%"))
            ->latest()->paginate(30);
        return view('admin.users.index', compact('users'));
    }

    public function usersAddFunds(Request $request, User $user)
    {
        $request->validate(['amount' => 'required|numeric|min:0.01', 'note' => 'nullable|string|max:200']);
        $user->increment('funds', $request->amount);
        Transaction::create([
            'user_id'     => $user->id,
            'amount'      => $request->amount,
            'type'        => 'deposit',
            'status'      => 'completed',
            'description' => 'Admin credit: ' . ($request->note ?? 'Manual top-up'),
        ]);
        return back()->with('success', "\${$request->amount} added to {$user->name}'s account.");
    }

    // ── Transactions ───────────────────────────────────────────────────────
    public function transactionsIndex()
    {
        $transactions = Transaction::with('user')->latest()->paginate(30);
        return view('admin.transactions.index', compact('transactions'));
    }

    public function transactionsApprove(Transaction $transaction)
    {
        if ($transaction->status !== 'pending') {
            return back()->with('error', 'Transaction already processed.');
        }
        DB::transaction(function () use ($transaction) {
            $transaction->user->increment('funds', $transaction->amount);
            $transaction->update(['status' => 'completed']);
        });
        return back()->with('success', "Transaction approved — \${$transaction->amount} credited to {$transaction->user->name}.");
    }

    // ── Tickets ────────────────────────────────────────────────────────────
    public function ticketsIndex()
    {
        $tickets = Ticket::with('user')->latest()->paginate(20);
        return view('admin.tickets.index', compact('tickets'));
    }

    public function ticketsReply(Request $request, Ticket $ticket)
    {
        $request->validate(['message' => 'required|string|max:5000']);
        \App\Models\TicketMessage::create([
            'ticket_id' => $ticket->id,
            'user_id'   => auth()->id(),
            'message'   => $request->message,
            'is_admin'  => true,
        ]);
        $ticket->update(['status' => 'pending']);
        return back()->with('success', 'Reply sent.');
    }

    public function ticketsClose(Ticket $ticket)
    {
        $ticket->update(['status' => 'closed']);
        return back()->with('success', 'Ticket closed.');
    }

    // ── Settings ───────────────────────────────────────────────────────────
    public function settings()
    {
        return view('admin.settings');
    }
}
