<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    DashboardController,
    OrderController,
    ServiceController,
    FundsController,
    AnalyticsController,
    ReferralController,
    TicketController,
    TransactionController,
};
use App\Http\Controllers\Admin\AdminController;

// ── Public routes ──────────────────────────────────────────────────────────
Route::get('/', function () {
    return auth()->check()
        ? redirect()->route('dashboard')
        : view('landing');
})->name('home');

// ── Auth routes ────────────────────────────────────────────────────────────
Auth::routes(['verify' => false]);

// ── Authenticated user routes ──────────────────────────────────────────────
Route::middleware(['auth', 'App\Http\Middleware\InjectExchangeRate'])->group(function () {

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Orders
    Route::get('/orders',           [OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/new',       [OrderController::class, 'create'])->name('orders.create');
    Route::post('/orders',          [OrderController::class, 'store'])->name('orders.store');
    Route::get('/orders/{order}',   [OrderController::class, 'show'])->name('orders.show');

    // Services
    Route::get('/services',         [ServiceController::class, 'index'])->name('services.index');

    // Funds
    Route::get('/funds',            [FundsController::class, 'index'])->name('funds.index');
    Route::post('/funds/stripe',    [FundsController::class, 'stripe'])->name('funds.stripe');
    Route::post('/funds/paypal',    [FundsController::class, 'paypal'])->name('funds.paypal');
    Route::post('/funds/manual',    [FundsController::class, 'manual'])->name('funds.manual');

    // Transactions
    Route::get('/transactions',     [TransactionController::class, 'index'])->name('transactions.index');

    // Analytics
    Route::get('/analytics',        [AnalyticsController::class, 'index'])->name('analytics.index');

    // Referrals
    Route::get('/referral',         [ReferralController::class, 'index'])->name('referral.index');

    // Support / Tickets
    Route::get('/support',          [TicketController::class, 'index'])->name('tickets.index');
    Route::get('/support/new',      [TicketController::class, 'create'])->name('tickets.create');
    Route::post('/support',         [TicketController::class, 'store'])->name('tickets.store');
    Route::get('/support/{ticket}', [TicketController::class, 'show'])->name('tickets.show');
    Route::post('/support/{ticket}/reply', [TicketController::class, 'reply'])->name('tickets.reply');
});

// ── Admin routes ───────────────────────────────────────────────────────────
Route::middleware(['auth', 'App\Http\Middleware\InjectExchangeRate'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

    Route::get('/',                        [AdminController::class, 'dashboard'])->name('dashboard');

    // API Providers — WHERE YOU ADD YOUR API KEYS
    Route::get('/providers',               [AdminController::class, 'providersIndex'])->name('providers.index');
    Route::get('/providers/create',        [AdminController::class, 'providersCreate'])->name('providers.create');
    Route::post('/providers',              [AdminController::class, 'providersStore'])->name('providers.store');
    Route::get('/providers/{provider}/edit', [AdminController::class, 'providersEdit'])->name('providers.edit');
    Route::put('/providers/{provider}',    [AdminController::class, 'providersUpdate'])->name('providers.update');
    Route::post('/providers/{provider}/sync', [AdminController::class, 'syncProvider'])->name('providers.sync');

    // Sync all
    Route::post('/sync',                   [AdminController::class, 'syncAll'])->name('sync.all');
    Route::post('/sync-services',          [AdminController::class, 'syncAll'])->name('sync'); // alias

    // Orders
    Route::get('/orders',                  [AdminController::class, 'ordersIndex'])->name('orders.index');
    Route::patch('/orders/{order}/status', [AdminController::class, 'ordersUpdateStatus'])->name('orders.status');

    // Users
    Route::get('/users',                   [AdminController::class, 'usersIndex'])->name('users.index');
    Route::post('/users/{user}/add-funds', [AdminController::class, 'usersAddFunds'])->name('users.add_funds');

    // Transactions
    Route::get('/transactions',            [AdminController::class, 'transactionsIndex'])->name('transactions.index');
    Route::post('/transactions/{transaction}/approve', [AdminController::class, 'transactionsApprove'])->name('transactions.approve');

    // Tickets
    Route::get('/tickets',                 [AdminController::class, 'ticketsIndex'])->name('tickets.index');
    Route::post('/tickets/{ticket}/reply', [AdminController::class, 'ticketsReply'])->name('tickets.reply');
    Route::post('/tickets/{ticket}/close', [AdminController::class, 'ticketsClose'])->name('tickets.close');

    // Settings
    Route::get('/settings',                [AdminController::class, 'settings'])->name('settings');

    // Services management
    Route::get('/services',                [ServiceController::class, 'index'])->name('services.index');
});
